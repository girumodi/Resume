# Canva Resume Design Guide - Girish Teli

## **Template Specifications**

### **Page Setup**
- **Size:** A4 (210 x 297 mm) or US Letter (8.5 x 11 inches)
- **Orientation:** Portrait
- **Margins:** 0.5 inches all sides

### **Color Palette**
- **Primary Blue:** #2E5BBA or #3B82F6 (Header background)
- **Secondary Blue:** #E3F2FD or #DBEAFE (Accent sections)
- **Dark Text:** #1F2937 or #374151
- **Light Text:** #6B7280
- **White:** #FFFFFF (Background)
- **Divider Lines:** #E5E7EB

### **Typography**
- **Main Header (Name):** Montserrat Bold, 28-32pt, White
- **Subtitle (Job Title):** Montserrat Medium, 16-18pt, Light Blue/White
- **Section Headers:** Montserrat SemiBold, 14-16pt, Dark Blue
- **Body Text:** Open Sans Regular, 10-11pt, Dark Gray
- **Contact Info:** Open Sans Regular, 9-10pt

---

## **Layout Structure**

### **Header Section** (Top 25% of page)
**Background:** Primary Blue Gradient
**Content:**
- **Left Side (60%):**
  - Name: "GIRISH TELI"
  - Title: "Software Test Engineer"
  - Tagline: "1 Year 11 Months Experience | Manual & Automation Testing"

- **Right Side (40%):**
  - Professional photo (circular, 120px diameter)
  - Contact info below photo

### **Contact Information** (In header, right side)
```
📧 gmodi7679@gmail.com
📱 +91-9157382201
📍 Ahmedabad, India
🔗 linkedin.com/in/girish-modi-4505781a1
💻 github.com/girumodi/girumodi
```

### **Main Body** (Two-column layout)

#### **Left Column (35% width)**

**TECHNICAL SKILLS**
- Section background: Light blue (#E3F2FD)
- Add small icons for each skill category
```
🔧 Programming
• Java
• JavaScript

⚡ Automation
• Selenium WebDriver
• TestNG Framework

🔗 API Testing
• Postman
• REST API

⚙️ Performance
• Apache JMeter
• Load Testing

📊 Version Control
• Git
• GitHub

🧪 Testing Types
• Functional Testing
• UI/UX Testing
• Black Box Testing
• Mobile Testing
• SEO Testing
```

**CERTIFICATIONS**
```
✅ Software Testing - Tech Mahindra
🎯 ISTQB Foundation Level (In Progress)
```

**LANGUAGES**
```
🗣️ Hindi - Full Professional
🗣️ English - Full Professional  
🗣️ Gujarati - Full Professional
```

#### **Right Column (65% width)**

**PROFESSIONAL SUMMARY**
*Background: White with subtle border*
```
Dedicated Software Test Engineer with 1 year 11 months of hands-on experience in manual and automation testing. Specializing in ecommerce and travel agency applications with expertise in Scrum methodologies. Developed custom automation scripts for URL verification and SEO testing. Proven track record in functional, API, and performance testing using industry-standard tools.
```

**PROFESSIONAL EXPERIENCE**
```
Quality Assurance Engineer
Addweb Solution | Aug 2023 – Present
Ahmedabad, India

• Active Scrum team member with daily standups and sprint planning
• Developed automated URL verification scripts for SEO and console error testing
• Conducted end-to-end testing for ecommerce and travel agency platforms
• Performed manual and automation testing using Selenium, TestNG, and Postman
• Collaborated with cross-functional teams for quality delivery
• Maintained test documentation and defect tracking
```

**KEY PROJECTS**
*Each project in a separate box with light background*

```
🚀 Travelnationco.uk | June 2024
• Lead QA for travel booking platform
• Tested travel card integration and email workflows
• Automated booking process validation

⚡ Volt Active Data System | February 2024  
• Comprehensive system testing and UI validation
• Link redirection and navigation testing

🔐 Silverfort.com Security Platform
• End-to-end testing from development to production
• Security feature validation and compliance testing

🎯 A-lign Platform
• System testing with UI and functional focus
• Complete link and button functionality verification
```

**EDUCATION**
```
Master of Computer Applications (MCA)
RBIMS - Gujarat Technological University | 2023
CGPA: 6.7/10 (67%)
```

---

## **Design Elements**

### **Icons to Use in Canva**
- 📧 📱 📍 🔗 💻 (Contact)
- 🔧 ⚡ 🔗 ⚙️ 📊 🧪 (Skills)
- 🚀 ⚡ 🔐 🎯 (Projects)
- ✅ 🎯 (Certifications)
- 🗣️ (Languages)

### **Visual Elements**
- **Progress Bars:** For skill levels (80-90% filled)
- **Divider Lines:** Thin lines between sections
- **Rounded Rectangles:** For project boxes and sections
- **Drop Shadows:** Subtle shadows on main sections

### **Spacing Guidelines**
- **Section spacing:** 15-20px between sections
- **Line spacing:** 1.2-1.4 for body text
- **Paragraph spacing:** 8-12px
- **Icon spacing:** 5px from text

---

## **Canva Creation Steps**

1. **Start:** Choose "Resume" template in Canva
2. **Background:** Set to white, add blue header rectangle
3. **Photo:** Add circular frame in top right
4. **Text Boxes:** Create separate boxes for each section
5. **Colors:** Apply the color palette consistently
6. **Icons:** Search and add relevant icons from Canva library
7. **Alignment:** Use Canva's alignment tools for perfect spacing
8. **Export:** Download as PDF (high quality) for applications

---

## **Pro Tips**
- Keep consistent spacing throughout
- Use the same icon style family
- Ensure text is readable (good contrast)
- Test print preview before finalizing
- Save as template for future updates

**Final Result:** A modern, professional resume that stands out while maintaining ATS compatibility!